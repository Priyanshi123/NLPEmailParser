package com.ind.service;

import java.util.List;

public class TransactiontTest {
	
	private List<String> transactionAddressChange ;
	
	public  TransactiontTest()
	{
		transactionAddressChange.add("Address Change");
		transactionAddressChange.add("Address");
		transactionAddressChange.add("Address is");
		transactionAddressChange.add("change the address");
		transactionAddressChange.add("update the address");
		transactionAddressChange.add("change of address");
		transactionAddressChange.add("address changes");
		transactionAddressChange.add("address updated");
		transactionAddressChange.add("update the address");
	}

	public List<String> getTransactionAddressChange() {
		return transactionAddressChange;
	}

	

}
