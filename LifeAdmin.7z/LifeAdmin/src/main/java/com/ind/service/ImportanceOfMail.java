package com.ind.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.mail.Message;
import javax.mail.MessagingException;

import opennlp.tools.namefind.BioCodec;
import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.namefind.NameSampleDataStream;
import opennlp.tools.namefind.TokenNameFinder;
import opennlp.tools.namefind.TokenNameFinderFactory;
import opennlp.tools.namefind.TokenNameFinderModel;
import opennlp.tools.tokenize.SimpleTokenizer;
import opennlp.tools.util.InputStreamFactory;
import opennlp.tools.util.MarkableFileInputStreamFactory;
import opennlp.tools.util.ObjectStream;
import opennlp.tools.util.PlainTextByLineStream;
import opennlp.tools.util.Span;
import opennlp.tools.util.TrainingParameters;

public class ImportanceOfMail{
	static TokenNameFinderModel nameFinderModel = null;

	public void getPriority(Message message) throws MessagingException, IOException {

		// reading training data
		InputStreamFactory in = null;
		try {
			in = new MarkableFileInputStreamFactory(new File("TrainingModelForImportance.txt"));
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
		}

		ObjectStream sampleStream = null;
		try {
			sampleStream = new NameSampleDataStream(
					new PlainTextByLineStream(in, StandardCharsets.UTF_8));
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// setting the parameters for training
		TrainingParameters params = new TrainingParameters();
		params.put(TrainingParameters.ITERATIONS_PARAM, 70);
		params.put(TrainingParameters.CUTOFF_PARAM, 1);

		// training the model using TokenNameFinderModel class 

		try {
			nameFinderModel = NameFinderME.train("en", null, sampleStream,
					params, TokenNameFinderFactory.create(null, null, Collections.emptyMap(), new BioCodec()));
		} catch (IOException e) {
			e.printStackTrace();
		}

		// saving the model to "ner-custom-model.bin" file
		try {
			File output = new File("ner-custom1-model.bin");
			FileOutputStream outputStream = new FileOutputStream(output);
			nameFinderModel.serialize(outputStream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// testing the model and printing the types it found in the input sentence
		TokenNameFinder nameFinder = new NameFinderME(nameFinderModel);
		String messageBody = ReadInbox.getTextFromMessage(message);
		HashMap max=tokenizeInput(messageBody,"MessageBody");
		Map.Entry<String,Double> entry = (Entry<String, Double>) max.entrySet().iterator().next();
		Double key = entry.getValue();
		String value = entry.getKey();
		//System.out.println(max);
		String messageSubject = message.getSubject();
		//	System.out.println(messageSubject);
		HashMap max1=tokenizeInput(messageSubject,"MessageSubject");
		//System.out.println(max1);
		Map.Entry<String,Double> entry1 = (Entry<String, Double>) max1.entrySet().iterator().next();
		Double key1 = entry1.getValue();
		String value1 = entry1.getKey();
		int retval =key.compareTo(key1);  
		
		if(retval > 0) {
			System.out.println(key+"   "+value);
		} else if(retval < 0) {
			System.out.println(key1+"     "+value1);
		} else {
			System.out.println("Not Found");
		}
	}







	public static HashMap<String, Double> tokenizeInput(String input,String messageElement){
		TokenNameFinder nameFinder = new NameFinderME(nameFinderModel);
		SimpleTokenizer simpleTokenizersubject = SimpleTokenizer.INSTANCE;
		String inputvalue[] = simpleTokenizersubject.tokenize(input);
		Span[] priorities = nameFinder.find(inputvalue);
		double large=0.00;
		String prior=null;
		for(Span priority:priorities){
			String personName="";
			for(int i=priority.getStart();i<priority.getEnd();i++){

				personName+=inputvalue[i]+" ";
			}
			if(priority.getProb()>large)
			{
				large=priority.getProb();
				prior=personName;
			}
		}

		HashMap<String, Double> map = new HashMap<>();
		map.put(prior, large);

		return map;
	}


}