package com.ind.service;

import java.io.IOException;

import javax.mail.MessagingException;

public class Test {

	public static void main(String[] args) throws MessagingException, IOException {
		ReadInbox obj= new ReadInbox();
		obj.readFromInbox();
		
		/*Pattern testPattern = Pattern.compile("test");
		String sentence[] = new String[]{"a", "test", "b", "c"};

		Pattern[] patterns = new Pattern[]{testPattern};
		Map<String, Pattern[]> regexMap = new HashMap<>();
		String type = "testtype";

		regexMap.put(type, patterns);

		RegexNameFinder finder =
		new RegexNameFinder(regexMap);

		Span[] result = finder.find(sentence);*/
	}

}
