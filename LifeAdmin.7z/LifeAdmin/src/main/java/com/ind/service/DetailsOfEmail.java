package com.ind.service;

import java.util.List;

public class DetailsOfEmail {
	
	private List policyNo;
	private String transaction;
	private String importance;
	
	public DetailsOfEmail() {
		super();
	}

	public DetailsOfEmail(List policyNo, String transaction, String importance) {
		super();
		this.policyNo = policyNo;
		this.transaction = transaction;
		this.importance = importance;
	}

	public List getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(List policyNo) {
		this.policyNo = policyNo;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

	public String getImportance() {
		return importance;
	}

	public void setImportance(String importance) {
		this.importance = importance;
	}
	

}
