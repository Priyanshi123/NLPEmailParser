package com.ind.service;

import java.io.IOException;

import javax.mail.Message;
import javax.mail.MessagingException;

public class SendToBPM {

	public static void main(String[] args) {

		ReadInbox readInbox = new ReadInbox();
		try {
			Message[] message = readInbox.readFromInbox();
			TransactionIndentifiaction transactionIndentifiaction = new TransactionIndentifiaction();
			ImportanceOfMail importanceOfMail = new ImportanceOfMail();
			for (Message msg : message) {
				transactionIndentifiaction.getTransaction(msg);
				importanceOfMail.getPriority(msg);
			}
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
