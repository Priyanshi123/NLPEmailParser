package com.ind.service;

public class IdentifyPolicyNumber {

	public Integer policyNumber(String token){
		int policynumber=0;
		if(token.matches("[0-9]+")){
			policynumber = Integer.parseInt(token);
		System.out.println(policynumber);
		}
		return policynumber;
	}

}
