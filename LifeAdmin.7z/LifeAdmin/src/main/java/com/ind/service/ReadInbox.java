package com.ind.service;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeMultipart;

public class ReadInbox {

	public static String getTextFromMessage(Message message) throws MessagingException, IOException {
		String result = "";
		if (message.isMimeType("text/plain")) {
			result = message.getContent().toString();
		} else if (message.isMimeType("multipart/*")) {
			MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
			result = getTextFromMimeMultipart(mimeMultipart);
		}
		return result;
	}

	public static String getTextFromMimeMultipart(
			MimeMultipart mimeMultipart)  throws MessagingException, IOException{
		String result = "";
		int count = mimeMultipart.getCount();
		for (int i = 0; i < count; i++) {
			BodyPart bodyPart = mimeMultipart.getBodyPart(i);
			if (bodyPart.isMimeType("text/plain")) {
				result = result + "\n" + bodyPart.getContent();
				break; 
			} else if (bodyPart.isMimeType("text/html")) {
				String html = (String) bodyPart.getContent();
				result = result + "\n" + org.jsoup.Jsoup.parse(html).text();
			} else if (bodyPart.getContent() instanceof MimeMultipart){
				result = result + getTextFromMimeMultipart((MimeMultipart)bodyPart.getContent());
			}
		}
		return result;
	}

	public Message[] readFromInbox() throws MessagingException, IOException{
		String host = "imap.gmail.com";// change accordingly
		String mailStoreType = "pop3";
		String username = "LA.stpInnovation@gmail.com";// change accordingly
		String password = "PRATEEKsingh1#";// change accordingly

		Properties properties = new Properties();

		properties.put("mail.imap.host", host);
		properties.put("mail.imap.port", "995");
		properties.put("mail.imap.starttls.enable", "true");
		Session emailSession = Session.getDefaultInstance(properties);

		//create the POP3 store object and connect with the pop server
		Store store = emailSession.getStore("imaps");
		store.connect(host, username, password);
		//create the folder object and open it
		Folder emailFolder = store.getFolder("INBOX");
		emailFolder.open(Folder.READ_ONLY);
		// retrieve the messages from the folder in an array and print it
		Message[] messages = emailFolder.getMessages();		
		//emailFolder.close(false);
		//store.close();
		return messages;
	} 

}
