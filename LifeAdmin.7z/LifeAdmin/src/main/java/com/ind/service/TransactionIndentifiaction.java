package com.ind.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMultipart;

import opennlp.tools.namefind.BioCodec;
import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.namefind.NameSampleDataStream;
import opennlp.tools.namefind.TokenNameFinder;
import opennlp.tools.namefind.TokenNameFinderFactory;
import opennlp.tools.namefind.TokenNameFinderModel;
import opennlp.tools.tokenize.SimpleTokenizer;
import opennlp.tools.util.InputStreamFactory;
import opennlp.tools.util.MarkableFileInputStreamFactory;
import opennlp.tools.util.ObjectStream;
import opennlp.tools.util.PlainTextByLineStream;
import opennlp.tools.util.Span;
import opennlp.tools.util.TrainingParameters;

/**
 * NER Training in OpenNLP with Name Finder Training Java Example
 * @author www.tutorialkart.com
 */
public class TransactionIndentifiaction {
	
	static TokenNameFinderModel nameFinderModel = null;
	
	public void getTransaction(Message message) throws MessagingException, IOException {

		// reading training data
		InputStreamFactory in = null;
		try {
			in = new MarkableFileInputStreamFactory(new File("TrainingModel.txt"));
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
		}

		ObjectStream sampleStream = null;
		try {
			sampleStream = new NameSampleDataStream(
					new PlainTextByLineStream(in, StandardCharsets.UTF_8));
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// setting the parameters for training
		TrainingParameters params = new TrainingParameters();
		params.put(TrainingParameters.ITERATIONS_PARAM, 70);
		params.put(TrainingParameters.CUTOFF_PARAM, 1);

		// training the model using TokenNameFinderModel class 
		
		try {
			nameFinderModel = NameFinderME.train("en", null, sampleStream,
					params, TokenNameFinderFactory.create(null, null, Collections.emptyMap(), new BioCodec()));
		} catch (IOException e) {
			e.printStackTrace();
		}

		// saving the model to "ner-custom-model.bin" file
		try {
			File output = new File("ner-custom-model.bin");
			FileOutputStream outputStream = new FileOutputStream(output);
			nameFinderModel.serialize(outputStream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// testing the model and printing the types it found in the input sentence
		TokenNameFinder nameFinder = new NameFinderME(nameFinderModel);
		ReadInbox readInbox = new ReadInbox();
	
			String messageBody = getTextFromMessage(message);
			HashMap max=tokenizeInput(messageBody,"MessageBody");
			Map.Entry<String,Double> entry = (Entry<String, Double>) max.entrySet().iterator().next();
			Double key = entry.getValue();
			String value = entry.getKey();
			String messageSubject = message.getSubject();
			HashMap max1=tokenizeInput(messageSubject,"MessageSubject");
			Map.Entry<String,Double> entry1 = (Entry<String, Double>) max1.entrySet().iterator().next();
			Double key1 = entry1.getValue();
			String value1 = entry1.getKey();
		     int retval =key.compareTo(key1);  
		   
		      if(retval > 0) {
		         System.out.println(key+"   "+value);
		      } else if(retval < 0) {
		        System.out.println(key1+"     "+value1);
		      } else {
		         System.out.println("Not found");
		      }
		}
		

	

		public static HashMap<String, Double> tokenizeInput(String input,String messageElement){
			TokenNameFinder nameFinder = new NameFinderME(nameFinderModel);
			SimpleTokenizer simpleTokenizersubject = SimpleTokenizer.INSTANCE;
			String inputvalue[] = simpleTokenizersubject.tokenize(input);
			IdentifyPolicyNumber identifyPolicyNumber = new IdentifyPolicyNumber();
			for(String policy: inputvalue){
				if(policy.length()==7){
					identifyPolicyNumber.policyNumber(policy);
				}
			}
			//System.out.println("Finding types in the sentence for "+messageElement);
			Span[] transactions = nameFinder.find(inputvalue);
			double large=0.00;
			String trans=null;
			for(Span transaction:transactions){
				String personName="";
				for(int i=transaction.getStart();i<transaction.getEnd();i++){
					
					personName+=inputvalue[i]+" ";
				}
				if(transaction.getProb()>large)
				{
					large=transaction.getProb();
					//trans=transaction.getType();
					trans=personName;
				}
			
				//System.out.println(transaction.getType()+" : "+personName+"\t [probability="+transaction.getProb()+"]");
			}
			
			HashMap<String, Double> map = new HashMap<>();
			map.put(trans, large);
			
			return map;
		}

	  








	private static String getTextFromMessage(Message message) throws MessagingException, IOException {
		String result = "";
		if (message.isMimeType("text/plain")) {
			result = message.getContent().toString();
		} else if (message.isMimeType("multipart/*")) {
			MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
			result = getTextFromMimeMultipart(mimeMultipart);
		}
		return result;
	}

	private static String getTextFromMimeMultipart(
			MimeMultipart mimeMultipart)  throws MessagingException, IOException{
		String result = "";
		int count = mimeMultipart.getCount();
		for (int i = 0; i < count; i++) {
			BodyPart bodyPart = mimeMultipart.getBodyPart(i);
			if (bodyPart.isMimeType("text/plain")) {
				result = result + "\n" + bodyPart.getContent();
				break; 
			} else if (bodyPart.isMimeType("text/html")) {
				String html = (String) bodyPart.getContent();
				result = result + "\n" + org.jsoup.Jsoup.parse(html).text();
			} else if (bodyPart.getContent() instanceof MimeMultipart){
				result = result + getTextFromMimeMultipart((MimeMultipart)bodyPart.getContent());
			}
		}
		return result;
	}

}