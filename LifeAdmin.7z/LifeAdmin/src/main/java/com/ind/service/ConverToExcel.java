package com.ind.service;

import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.ind.service.DetailsOfEmail;

public class ConverToExcel {
	
	public static void main(String arg[])
	{
		List <DetailsOfEmail> employeeDtoList=null;
		createExcel("C:/Workspace/EmployeeInfo.xlsx",employeeDtoList);
	}
	
		private static void createExcel(String filePath, List <DetailsOfEmail> employeeDtoList)
		{
			if(filePath!=null && !"".equals(filePath.trim()))
			{
				try
				{
					/* Create excel workbook. */
					Workbook excelWookBook = new XSSFWorkbook();
					
					/* */
					CreationHelper createHelper = excelWookBook.getCreationHelper();
					
					/* Create employee info sheet. */
					Sheet employeeSheet = excelWookBook.createSheet("Employee Info");
		
					/* Create employee info row. Row number start with 0.
					 * The input parameter for method createRow(int rowNumber) is the row number that will be created.
					 * */
					
					/* First create header row. */
					Row headerRow = employeeSheet.createRow(0);
					
					headerRow.createCell(0).setCellValue("policy no");
					headerRow.createCell(1).setCellValue("Transaction");
					//headerRow.createCell(2).setCellValue("request type");
					List<String> x =null;
					x.add("1112223");
					x.add("7878788");
					employeeDtoList.add(new DetailsOfEmail(x,"transaction","rush") );
					/* Loop for the employee dto list, add each employee data info into one row. */
					if(employeeDtoList!=null)
					{
						int size = employeeDtoList.size();
						for(int i=0;i<size;i++)
						{
							DetailsOfEmail eDto = employeeDtoList.get(i);
							
							/* Create row to save employee info. */
							Row row = employeeSheet.createRow(i+1);
							
							row.createCell(0).setCellValue(eDto.getImportance());
							row.createCell(1).setCellValue(eDto.getTransaction());
							
						}
					}
					
					/* Write to excel file */
					FileOutputStream fOut = new FileOutputStream(filePath);
					excelWookBook.write(fOut);
					fOut.close();
					
					System.out.println("File " + filePath + " is created successfully. ");
				}catch(Exception ex)
				{
					ex.printStackTrace();
				}
			}

}
}
