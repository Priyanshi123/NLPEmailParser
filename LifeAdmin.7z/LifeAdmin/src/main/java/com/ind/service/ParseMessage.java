package com.ind.service;


import opennlp.tools.tokenize.SimpleTokenizer;

public class ParseMessage {


	public static void main(String[] args) {
		String sentenceone="FW: 1111111 Testing, Test";
		//MimeMessage message = new Mime();

		SimpleTokenizer simpleTokenizersubject = SimpleTokenizer.INSTANCE;
		String subjectdata[] = simpleTokenizersubject.tokenize(sentenceone);

	/*	for(String token : subjectdata) {         
			System.out.println(token);  
		} */

		String sentenctwo="Hello,  "+

"Please update the address and confirm once completed."+
"5454 Virginia Avenue"+
"Durham, NC 78885"+
"Test"+
"Account Manager"+
"sor Insurance Associates, Inc."+
"Email abby@insurance.com"+
"Telephone 111 111 1126 ext. 316"+
"Fax (878) 896 6666"+
"21820 Burbank Blvd Ste 100 South"+
"Woodland Hills CA 1245-5656"+ 

"(Windsor eagle logo) WINDSOR INSURANCE <https://www.insurance.com/> "+
"Relationship, Service, Continuity ";

		SimpleTokenizer simpleTokenizerbody = SimpleTokenizer.INSTANCE;
		String bodydata[] = simpleTokenizerbody.tokenize(sentenctwo);

		for(String token : bodydata) {         
			System.out.println(token);  
		} 


	}

}
